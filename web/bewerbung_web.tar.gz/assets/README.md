Willkommen zu meiner interaktiven Bewerbung!

Dieses Projekt habe ich mit Python und Pygame erstellt, um meine
Bewerbung etwas persönlicher zu gestalten und gleichzeitig erste
praktische Erfahrungen in der Programmierung zu sammeln.

## Über das Projekt

Die Anwendung enthält:

- eine interaktive Vorstellung meiner Person
- meine Stärken und bisherigen IT-Kenntnisse
- meine Motivation für den Bereich IT-Systemtechnik
- ein selbst erstelltes kleines Jump-and-Run-Minispiel
- Charakteranimationen
- Kollisionsabfragen und Plattformen
- ein eigenes Pixel-Art-Design

## Verwendete Technologien

- Python
- Pygame

## Hintergrund

Ich beschäftige mich aktuell intensiv mit IT und Programmierung und
möchte meine bisherigen Kenntnisse im Rahmen einer Ausbildung und
eines Praktikums in der IT-Systemtechnik weiter ausbauen.

Dieses Projekt ist im Zuge meiner Bewerbung entstanden und soll einen
kleinen Einblick in meine Lernbereitschaft und mein Interesse an der IT geben.# bewerbi