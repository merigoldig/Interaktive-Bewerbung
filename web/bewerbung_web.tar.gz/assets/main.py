import pygame
import random
import asyncio

# =====================
# START
# =====================

pygame.init()

# =====================
# FENSTER
# =====================

fenster = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Willkommen zu meiner Bewerbung!")

# Hintergrundbild laden
hintergrund = pygame.image.load("hintergrund.png").convert()

# Bild auf Fenstergröße bringen
hintergrund = pygame.transform.scale(hintergrund, (800, 600))

# Minigame-Hintergrund laden
hintergrund_minigame = pygame.image.load(
    "hintergrund_minigame.png"
).convert()

hintergrund_minigame = pygame.transform.scale(
    hintergrund_minigame,
    (800, 600)
)

# Zielbild laden
ziel_bild = pygame.image.load("ziel.png").convert_alpha()

# Größe anpassen
ziel_bild = pygame.transform.scale(ziel_bild, (100, 80))

# =====================
# BUTTONS
# =====================

def button_rects():
    return {
        "start_button": pygame.Rect(300, 200, 220, 60),
        "kontakt_button": pygame.Rect(300, 280, 220, 60),
        "ende_button": pygame.Rect(300, 360, 220, 60)
    }


def bewerbung_button_rects():
    return {
        "ueber_mich_button": pygame.Rect(300, 170, 220, 50),
        "staerken_button": pygame.Rect(300, 230, 220, 50),
        "it_button": pygame.Rect(300, 290, 220, 50),
        "motivation_button": pygame.Rect(300, 350, 220, 50)
    }


# Zurück-Button
zurück_button = pygame.Rect(30, 520, 220, 60)

# Weiter-Button
weiter_button = pygame.Rect(550, 520, 220, 60)

# =====================
# SCHRIFT
# =====================

schrift = pygame.font.Font(None, 32)

# =====================
# TEXTE
# =====================

texte = {
    "start_button": "Starte Bewerbung",
    "kontakt_button": "Kontakt",
    "ende_button": "Beende Bewerbung",

    "ueber_mich_button": "Über mich",
    "staerken_button": "Meine Stärken",
    "it_button": "IT-Kenntnisse",
    "motivation_button": "Motivation"
}

# =====================
# BUTTON ZEICHNEN
# =====================

def button_zeichnen(rect, text, maus):

    # Farben
    dunkelbraun = (62, 39, 30)
    braun = (120, 76, 45)
    hellbraun = (156, 104, 60)
    hover_braun = (178, 122, 67)
    creme = (245, 226, 180)

    # Schatten
    schatten = pygame.Rect(
        rect.x + 5,
        rect.y + 5,
        rect.width,
        rect.height
    )

    pygame.draw.rect(
        fenster,
        dunkelbraun,
        schatten
    )

    # Farbe ändern
    if rect.collidepoint(maus):
        farbe = hover_braun
    else:
        farbe = braun

    # Hauptfläche
    pygame.draw.rect(
        fenster,
        farbe,
        rect
    )

    # Dunkler Rand
    pygame.draw.rect(
        fenster,
        dunkelbraun,
        rect,
        4
    )

    # Helle Kante
    pygame.draw.line(
        fenster,
        hellbraun,
        (rect.x + 6, rect.y + 6),
        (rect.right - 6, rect.y + 6),
        3
    )

    # Text
    text_flaeche = schrift.render(
        text,
        True,
        creme
    )

    text_rect = text_flaeche.get_rect(
        center=rect.center
    )

    fenster.blit(text_flaeche, text_rect)

    # Text erstellen
    text_surface = schrift.render(
        text,
        True,
        creme
    )

    # Text zentrieren
    text_rect = text_surface.get_rect(
        center=rect.center
    )

    # Text zeichnen
    fenster.blit(
        text_surface,
        text_rect
    )


# =====================
# TEXTE ZEICHNEN
# =====================

def text_zeichnen(text, position):

    text_surface = schrift.render(
        text,
        True,
        "black"
    )

    text_rect = text_surface.get_rect(
        center=position
    )

    fenster.blit(
        text_surface,
        text_rect
    )

# =====================
# PANELE
# =====================

def panel_zeichnen(rect):

    # Farben
    dunkelbraun = (62, 39, 30)
    braun = (105, 68, 43)
    creme = (232, 213, 174)

    # Schatten
    schatten = pygame.Rect(
        rect.x + 6,
        rect.y + 6,
        rect.width,
        rect.height
    )

    pygame.draw.rect(
        fenster,
        dunkelbraun,
        schatten
    )

    # Äußerer Holzrahmen
    pygame.draw.rect(
        fenster,
        braun,
        rect
    )

    # Innenfläche
    innen = pygame.Rect(
        rect.x + 8,
        rect.y + 8,
        rect.width - 16,
        rect.height - 16
    )

    pygame.draw.rect(
        fenster,
        creme,
        innen
    )

    # Dunkler Rand
    pygame.draw.rect(
        fenster,
        dunkelbraun,
        rect,
        4
    )

# =====================
# MINIGAME
# =====================

spieler = pygame.Rect(
    100,
    450,
    40,
    60
)

geschwindigkeit = 3
sprungkraft = -15
schwerkraft = 1

y_geschwindigkeit = 0
am_boden = True

animation_index = 0
animation_timer = 0
blickrichtung = "rechts"

# =====================
# CHARAKTER ANIMATIONEN
# =====================

# Stehen
stehen_frames = [
    pygame.image.load("sprites/stehen_1.png").convert_alpha(),
    pygame.image.load("sprites/stehen_2.png").convert_alpha()
]

# Laufen
laufen_frames = [
    pygame.image.load("sprites/laufen_1.png").convert_alpha(),
    pygame.image.load("sprites/laufen_2.png").convert_alpha(),
    pygame.image.load("sprites/laufen_3.png").convert_alpha(),
    pygame.image.load("sprites/laufen_4.png").convert_alpha()
]

# Springen
springen_frames = [
    pygame.image.load("sprites/sprung_1.png").convert_alpha(),
    pygame.image.load("sprites/sprung_2.png").convert_alpha(),
    pygame.image.load("sprites/sprung_3.png").convert_alpha()
]

# Landung
landung_bild = pygame.image.load(
    "sprites/landung.png"
).convert_alpha()

stehen_nach_landung = pygame.image.load(
    "sprites/stehen_nach_landung.png"
).convert_alpha()


# =====================
# SPRITES VERKLEINERN
# =====================

sprite_breite = 50
sprite_hoehe = 75

stehen_frames = [
    pygame.transform.scale(bild, (sprite_breite, sprite_hoehe))
    for bild in stehen_frames
]

laufen_frames = [
    pygame.transform.scale(bild, (sprite_breite, sprite_hoehe))
    for bild in laufen_frames
]

springen_frames = [
    pygame.transform.scale(bild, (sprite_breite, sprite_hoehe))
    for bild in springen_frames
]

landung_bild = pygame.transform.scale(
    landung_bild,
    (sprite_breite, sprite_hoehe)
)

stehen_nach_landung = pygame.transform.scale(
    stehen_nach_landung,
    (sprite_breite, sprite_hoehe)
)

animation_geschwindigkeit = 20

# Plattformen
plattformen = [
    pygame.Rect(0, 520, 800, 90),       
    pygame.Rect(150, 400, 180, 30),     
    pygame.Rect(400, 330, 180, 30),     
    pygame.Rect(620, 265, 150, 30)      
]

def plattform_zeichnen(plattform):

    # Erde
    pygame.draw.rect(
        fenster,
        (92, 62, 43),
        plattform
    )

    # Dunkle Erde unten
    pygame.draw.rect(
        fenster,
        (62, 45, 35),
        (
            plattform.x,
            plattform.y + 15,
            plattform.width,
            plattform.height - 15
        )
    )

    # Gras oben
    pygame.draw.rect(
        fenster,
        (73, 112, 69),
        (
            plattform.x,
            plattform.y,
            plattform.width,
            8
        )
    )

    # Hellere einzelne Gras-Pixel
    for x in range(plattform.x + 10, plattform.right - 5, 25):

        pygame.draw.rect(
            fenster,
            (105, 139, 78),
            (x, plattform.y - 3, 5, 5)
        )

# Ziel
ziel = pygame.Rect(
    665,
    200,
    100,
    80
)

# Level geschafft?
level_geschafft = False

# =====================
# ENDE BUTTONS
# =====================

ja_button = pygame.Rect(
    250,
    350,
    120,
    60
)

nein_button = pygame.Rect(
    430,
    350,
    120,
    60
)

# =====================
# STARTSEITE
# =====================

seite = "startseite"

running = True

# Uhr für 60 FPS
uhr = pygame.time.Clock()

# =====================
# HAUPTSCHLEIFE
# =====================

async def main():
    global running, seite, level_geschafft
    global y_geschwindigkeit, am_boden
    global animation_index, animation_timer, blickrichtung

    while running:

        # Hintergrund
        fenster.blit(hintergrund, (0, 0))

        # Mausposition
        maus = pygame.mouse.get_pos()

        # =====================
        # EVENTS
        # =====================

        for event in pygame.event.get():

            # Fenster schließen
            if event.type == pygame.QUIT:
                running = False

            # =====================
            # MAUSKLICK
            # =====================

            if event.type == pygame.MOUSEBUTTONDOWN:

                # =====================
                # STARTSEITE
                # =====================

                if seite == "startseite":

                    for name, rect in button_rects().items():

                        if rect.collidepoint(event.pos):

                            print(name, "wurde geklickt!")

                            if name == "start_button":
                                seite = "bewerbung_start"

                            elif name == "kontakt_button":
                                seite = "kontakt"

                            elif name == "ende_button":
                                running = False

                # =====================
                # BEWERBUNGSSEITE
                # =====================

                elif seite == "bewerbung_start":

                    if zurück_button.collidepoint(event.pos):
                        seite = "startseite"

                    if weiter_button.collidepoint(event.pos):
                        seite = "bewerbung_inhalt"

                # =====================
                # BEWERBUNGSINHALT
                # =====================

                elif seite == "bewerbung_inhalt":

                    if weiter_button.collidepoint(event.pos):
                        seite = "minigame"

                    for name, rect in bewerbung_button_rects().items():

                        if rect.collidepoint(event.pos):

                            print(name, "wurde geklickt!")

                            if name == "ueber_mich_button":
                                seite = "ueber_mich"

                            elif name == "staerken_button":
                                seite = "staerken"

                            elif name == "it_button":
                                seite = "it"

                            elif name == "motivation_button":
                                seite = "motivation"

                    if zurück_button.collidepoint(event.pos):
                        seite = "bewerbung_start"

                # =====================
                # ÜBER MICH
                # =====================

                elif seite == "ueber_mich":

                    if zurück_button.collidepoint(event.pos):
                        seite = "bewerbung_inhalt"

                # =====================
                # MEINE STÄRKEN
                # =====================

                elif seite == "staerken":

                    if zurück_button.collidepoint(event.pos):
                        seite = "bewerbung_inhalt"

                # =====================
                # IT-KENNTNISSE
                # =====================

                elif seite == "it":

                    if zurück_button.collidepoint(event.pos):
                        seite = "bewerbung_inhalt"

                # =====================
                # MOTIVATION
                # =====================

                elif seite == "motivation":

                    if zurück_button.collidepoint(event.pos):
                        seite = "bewerbung_inhalt"

                # =====================
                # KONTAKT
                # =====================

                elif seite == "kontakt":

                    if zurück_button.collidepoint(event.pos):
                        seite = "startseite"

                # =====================
                # MINIGAME
                # =====================

                elif seite == "minigame":

                    if level_geschafft:

                        if weiter_button.collidepoint(event.pos):

                            seite = "weg_button"

                # =====================
                # LEVEL GESCHAFFT SEITE
                # =====================

                elif seite == "weg_button":

                # JA wurde geklickt
                    if ja_button.collidepoint(event.pos):
                        seite = "kontakt"

                # NEIN wurde geklickt
                    elif nein_button.collidepoint(event.pos):

                # Neue Position suchen
                        while True:

                            neue_x = random.randint(50, 630)
                            neue_y = random.randint(150, 450)

                            neue_position = pygame.Rect(
                                neue_x,
                                neue_y,
                                nein_button.width,
                                nein_button.height
                            )

                # Prüfen, ob NEIN auf JA liegt
                            if not neue_position.colliderect(ja_button):
                                break

                # Neue Position übernehmen
                        nein_button.x = neue_x
                        nein_button.y = neue_y

        # =====================
        # STARTSEITE ZEICHNEN
        # =====================

        if seite == "startseite":

            for name, rect in button_rects().items():

                button_zeichnen(
                    rect,
                    texte[name],
                    maus
                )

        # =====================
        # BEWERBUNGSSEITE
        # =====================

        elif seite == "bewerbung_start":

            panel = pygame.Rect(200, 150, 400, 100)

            panel_zeichnen(panel)

            text_zeichnen(
                "Willkommen zu meiner Bewerbung",
                (400, 200)
            )

            button_zeichnen(
                zurück_button,
                "Zurück",
                maus
            )

            button_zeichnen(
                weiter_button,
                "Weiter",
                maus
            )

        # =====================
        # BEWERBUNGSINHALT
        # =====================

        elif seite == "bewerbung_inhalt":

            panel = pygame.Rect(200, 70, 400, 90)
            
            panel_zeichnen(panel)

            text_zeichnen(
                "Bewerbungsinhalte",
                (400, 120)
            )

            for name, rect in bewerbung_button_rects().items():

                button_zeichnen(
                    rect,
                    texte[name],
                    maus
                )

            button_zeichnen(
                zurück_button,
                "Zurück",
                maus
            )

            button_zeichnen(
                weiter_button,
                "Weiter",
                maus
            )

        # =====================
        # ÜBER MICH
        # =====================

        elif seite == "ueber_mich":

            fenster.blit(hintergrund, (0, 0))

            panel1 = pygame.Rect(100, 60, 600, 460)

            panel_zeichnen(panel1)
        
            text_zeichnen(
                "Über mich",
                (400, 90)
            )

            text_zeichnen(
                "Hallo!",
                (400, 150)
            )

            text_zeichnen(
                "Ich interessiere mich sehr für Computer,",
                (400, 200)
            )

            text_zeichnen(
                "Technik und Programmierung.",
                (400, 235)
            )

            text_zeichnen(
                "Ich probiere gerne neue Dinge aus und",
                (400, 290)
            )

            text_zeichnen(
                "finde es spannend, selbst herauszufinden,",
                (400, 325)
            )

            text_zeichnen(
                "wie etwas funktioniert.",
                (400, 360)
            )

            text_zeichnen(
                "In meiner Freizeit zocke ich gerne,",
                (400, 415)
            )

            text_zeichnen(
                "verbringe Zeit mit meinen Freunden",
                (400, 450)
            )

            text_zeichnen(
                "und meinen zwei Katzen.",
                (400, 485)
            )

            button_zeichnen(
                zurück_button,
                "Zurück",
                maus
            )

        # =====================
        # MEINE STÄRKEN
        # =====================

        elif seite == "staerken":

            fenster.blit(hintergrund, (0, 0))

            panel1 = pygame.Rect(100, 60, 600, 450)

            panel_zeichnen(panel1)

            text_zeichnen(
                "Meine wichtigsten Stärken",
                (400, 90)
            )

            text_zeichnen(
                "Lernbereitschaft -",
                (400, 160)
            )

            text_zeichnen(
                "Ich lerne gerne neue Dinge und möchte",
                (400, 195)
            )

            text_zeichnen(
                "mein Wissen ständig erweitern.",
                (400, 230)
            )

            text_zeichnen(
                "Problemlösung -",
                (400, 285)
            )

            text_zeichnen(
                "Wenn etwas nicht funktioniert, versuche",
                (400, 320)
            )

            text_zeichnen(
                "ich herauszufinden, wo das Problem liegt.",
                (400, 355)
            )

            text_zeichnen(
                "Genauigkeit -",
                (400, 410)
            )

            text_zeichnen(
                "Ich arbeite sorgfältig und achte auch",
                (400, 445)
            )

            text_zeichnen(
                "auf kleine Details.",
                (400, 480)
            )

            button_zeichnen(
                zurück_button,
                "Zurück",
                maus
            )

        # =====================
        # IT-KENNTNISSE
        # =====================

        elif seite == "it":

            fenster.blit(hintergrund, (0, 0))
            
            panel1 = pygame.Rect(100, 60, 600, 490)
            
            panel_zeichnen(panel1)
            
            text_zeichnen(
                "IT-Kenntnisse",
                (400, 90)
            )

            text_zeichnen(
                "Programmierung -",
                (400, 130)
            )

            text_zeichnen(
                "Erste Erfahrungen mit Python",
                (400, 165)
            )

            text_zeichnen(
                "Computer & Hardware -",
                (400, 215)
            )

            text_zeichnen(
                "Grundlagen über CPU, RAM, GPU,",
                (400, 250)
            )

            text_zeichnen(
                "Mainboard und SSD.",
                (400, 285)
            )

            text_zeichnen(
                "Betriebssysteme -",
                (400, 335)
            )

            text_zeichnen(
                "Grundkenntnisse über Windows,",
                (400, 370)
            )

            text_zeichnen(
                "Dateisysteme und UEFI.",
                (400, 405)
            )

            text_zeichnen(
                "Grundlagen -",
                (400, 455)
            )

            text_zeichnen(
                "Binär- und Hexadezimalsystem",
                (400, 490)
            )

            text_zeichnen(
                "ASCII Codierung",
                (400, 525)
            )

            button_zeichnen(
                zurück_button,
                "Zurück",
                maus
            )

        # =====================
        # MOTIVATION
        # =====================

        elif seite == "motivation":

            fenster.blit(hintergrund, (0, 0))
                    
            panel1 = pygame.Rect(60, 40, 680, 470)
                    
            panel_zeichnen(panel1)

            text_zeichnen(
                "Motivation",
                (400, 70)
            )

            text_zeichnen(
                "Von klein auf war ich bereits",
                (400, 130)
            )

            text_zeichnen(
                "von Computern und Technik begeistert.",
                (400, 165)
            )

            text_zeichnen(
                "Durch mein persönliches Interesse habe ich gemerkt, dass ich",
                (400, 215)
            )

            text_zeichnen(
                "meine berufliche Zukunft gerne in der IT gestalten möchte.",
                (400, 250)
            )

            text_zeichnen(
                "Ich möchte mein bisheriges Wissen erweitern,",
                (400, 300)
            )

            text_zeichnen(
                "praktische Erfahrungen sammeln und",
                (400, 335)
            )

            text_zeichnen(
                "immer mehr dazulernen.",
                (400, 370)
            )

            text_zeichnen(
                "Mein Ziel ist es, mich in der IT",
                (400, 420)
            )

            text_zeichnen(
                "weiterzuentwickeln und mir damit eine",
                (400, 455)
            )

            text_zeichnen(
                "neue berufliche Zukunft aufzubauen!",
                (400, 490)
            )

            button_zeichnen(
                zurück_button,
                "Zurück",
                maus
            )

        # =====================
        # KONTAKT
        # =====================

        elif seite == "kontakt":

            panel = pygame.Rect(180, 120, 440, 220)
            
            panel_zeichnen(panel)

            text_zeichnen(
                "Kontakt",
                (400, 150)
            )

            text_zeichnen(
                "Meine Kontaktdaten:",
                (400, 250)
            )

            text_zeichnen(
                "Siehe in den Bewerbungsunterlagen.",
                (400, 280)
            )

            text_zeichnen(
                ":)",
                (400, 310)
            )

            button_zeichnen(
                zurück_button,
                "Zurück",
                maus
            )

        # =====================
        # MINIGAME
        # =====================

        elif seite == "minigame":

            # Hintergrund
            fenster.blit(hintergrund_minigame, (0, 0))

            # =====================
            # LEVEL GESCHAFFT
            # =====================

            if level_geschafft:

                panel = pygame.Rect(200, 140, 400, 200)
                
                panel_zeichnen(panel)

                text_zeichnen(
                    "Level geschafft!",
                    (400, 220)
                )

                text_zeichnen(
                    "Du hast das Ziel erreicht!",
                    (400, 270)
                )

                button_zeichnen(
                    weiter_button,
                    "Weiter",
                    maus
                )

            # =====================
            # SPIEL
            # =====================

            else:

                # Tasten
                tasten = pygame.key.get_pressed()

                # Links
                if tasten[pygame.K_LEFT]:
                    spieler.x -= geschwindigkeit
                    blickrichtung = "links"

                # Rechts
                if tasten[pygame.K_RIGHT]:
                    spieler.x += geschwindigkeit
                    blickrichtung = "rechts"

                # Spieler im Bildschirm halten
                if spieler.left < 0:
                    spieler.left = 0

                if spieler.right > 800:
                    spieler.right = 800

                # Springen
                if tasten[pygame.K_SPACE] and am_boden:

                    y_geschwindigkeit = sprungkraft
                    am_boden = False

                # Gravitation
                y_geschwindigkeit += schwerkraft
                spieler.y += y_geschwindigkeit

                # Plattform-Kollision
                am_boden = False

                for plattform in plattformen:

                    if spieler.colliderect(plattform):

                        if y_geschwindigkeit > 0:

                            spieler.bottom = plattform.top
                            y_geschwindigkeit = 0
                            am_boden = True

                # Ziel überprüfen
                if spieler.colliderect(ziel):

                    level_geschafft = True

                # Zielbild zeichnen
                fenster.blit(ziel_bild, ziel)

                # =====================
                # CHARAKTER ANIMATION
                # =====================

                animation_timer += 1


                # SPRINGEN
                if not am_boden:

                    if y_geschwindigkeit < -5:
                        charakter_bild = springen_frames[0]

                    elif y_geschwindigkeit < 3:
                        charakter_bild = springen_frames[1]

                    else:
                        charakter_bild = springen_frames[2]


                # LAUFEN
                elif tasten[pygame.K_LEFT] or tasten[pygame.K_RIGHT]:

                    if animation_timer >= animation_geschwindigkeit:
                        animation_timer = 0
                        animation_index += 1

                        if animation_index >= len(laufen_frames):
                            animation_index = 0

                    charakter_bild = laufen_frames[animation_index]


                # STEHEN
                else:

                    if animation_timer >= 30:
                        animation_timer = 0
                        animation_index += 1

                        if animation_index >= len(stehen_frames):
                            animation_index = 0

                    charakter_bild = stehen_frames[
                        animation_index % len(stehen_frames)
                    ]


                # =====================
                # BLICKRICHTUNG
                # =====================

                if blickrichtung == "links":
                    charakter_bild = pygame.transform.flip(
                        charakter_bild,
                        True,
                        False
                    )


                # =====================
                # CHARAKTER ZEICHNEN
                # =====================

                charakter_rect = charakter_bild.get_rect(
                    midbottom=spieler.midbottom
                )

                fenster.blit(
                    charakter_bild,
                    charakter_rect
                )

        # =====================
        # WEGSPRINGENDER BUTTON
        # =====================

        elif seite == "weg_button":

            panel = pygame.Rect(200, 120, 400, 130)
            
            panel_zeichnen(panel)

            text_zeichnen(
                "Du hast es geschafft!",
                (400, 150)
            )

            text_zeichnen(
                "Interesse geweckt?",
                (400, 220)
            )

            # JA Button
            button_zeichnen(
                ja_button,
                "JA",
                maus
            )

            # NEIN Button
            button_zeichnen(
                nein_button,
                "NEIN",
                maus
            )

        # =====================
        # FENSTER AKTUALISIEREN
        # =====================

        pygame.display.flip()

        # 60 FPS
        uhr.tick(60)

        await asyncio.sleep(0)

# =====================
# ENDE
# =====================

    pygame.quit()

asyncio.run(main())